// HelloCube.js (c) 2012 matsuda
// Vertex shader program
var VSHADER_SOURCE =
  'attribute vec4 a_Position;\n' +
  'uniform mat4 u_matrix;\n' +//used for perspective
  'void main() {\n' +
  '  gl_Position = a_Position;\n' +//*u_matrix
  '}\n';

// Fragment shader program
var FSHADER_SOURCE =
  'precision mediump float;\n' +
  'void main() {\n' +
  '  gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);\n' +
  '}\n';
var a_Position;
var enableMove=true;
var numOfVerts=0;
var numOfVertsC=0;
var vertices = new Float32Array(5000);
var cVert = new Float32Array(5000);
var lineVert= new Float32Array(5000);
var indices = new Uint16Array(5000);
var vertexBuffer;
var indexBuffer;
var lineBuffer;
var numOfIndex=0;
var numOfCyl=0;
var gl;
function main() {
  setupIOSOR("fileName");
  // Retrieve <canvas> element
  var canvas = document.getElementById('webgl');

  // Get the rendering context for WebGL
  gl = getWebGLContext(canvas);
  if (!gl) {
    console.log('Failed to get the rendering context for WebGL');
    return;
  }

  // Initialize shaders
  if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
    console.log('Failed to intialize shaders.');
    return;
  }

  // Set the vertex coordinates and color
  var n = initVertexBuffers(gl);
  if (n < 0) {
    console.log('Failed to set the vertex information');
    return;
  }

  gl.clearColor(.9, .9, .9, 1.0);
  gl.enable(gl.DEPTH_TEST);

  // Clear color and depth buffer
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

  // Draw the cube
  gl.drawElements(gl.LINES, numOfIndex, gl.UNSIGNED_SHORT, 0);
  canvas.onmousedown = function(ev){ click(ev, gl, canvas, a_Position); };

}
//indices form triangles
function initVertexBuffers(gl) {
  var vertices = new Float32Array(500);
  // Create a buffer object
  vertexBuffer = gl.createBuffer();
  indexBuffer = gl.createBuffer();
  lineBuffer = gl.createBuffer();
  //set some start variables
  // Write the vertex coordinates and color to the buffer object
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, cVert, gl.STATIC_DRAW);

  var FSIZE = vertices.BYTES_PER_ELEMENT;
  // Assign the buffer object to a_Position and enable the assignment
  var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
  if(a_Position < 0) {
    console.log('Failed to get the storage location of a_Position');
    return -1;
  }
  gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, FSIZE * 3, 0);
  gl.enableVertexAttribArray(a_Position);
  // Assign the buffer object to a_Color and enable the assignment
  // Write the indices to the buffer object
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW);

  return indices.length;
}
var debug=false;
//get a start and an end point then generate based on them
function drawCircle(gl){
  //stores the data for the first and second point of the cylynders base
  if(!debug){
    //----based on code given on piazza-----//
    //gets the initial points from the lineVerts that arnt printed to the screen
    var frontPoint={
      x:lineVert[numOfVerts-6],
      y:lineVert[numOfVerts-5]
    }
    var backPoint={
      x:lineVert[numOfVerts-3],
      y:lineVert[numOfVerts-2]
    }
    //debug console log
    console.log("frontPoint: "+frontPoint.x+", "+frontPoint.y);
    console.log("backPoint: "+backPoint.x+", "+backPoint.y);
    //creates the I matrix at 4x4
    var rotMatrix=new Matrix4();
    //gives the axis
    var rot=new Vector3([backPoint.x-frontPoint.x,backPoint.y-frontPoint.y,0]);
    //normalize it
    rot=rot.normalize();
    //makes its magnitude 1
    //pass it the xyz of the normaized rotation axis
    rotMatrix.setRotate(30,rot.elements[0],rot.elements[1],rot.elements[2]);
    //point vector
    var pVec=new Vector3([0,0,.05]);
    //makes a perpendicular point
    cVert[numOfVertsC]=frontPoint.x;
    cVert[numOfVertsC+1]=frontPoint.y;
    cVert[numOfVertsC+2]=.05;
    //creats the perpendicular variable off by .2 in the z verticy
    numOfVertsC+=3;

    //change
    var num=0;
    var amountOfV=numOfVertsC;
    for (var i = 0; i <= 10; i++) {
      pVec=rotMatrix.multiplyVector3(pVec);
      num=amountOfV+i*3;
      cVert[num]=frontPoint.x+pVec.elements[0];
      cVert[num+1]=frontPoint.y+pVec.elements[1];
      cVert[num+2]=pVec.elements[2];
      numOfVertsC+=3;
    }
    //-----------------------------------------
    //sets the indicies
    //should be 24
    var index=numOfVertsC/3 - 12;
    console.log(numOfIndex);
    var p=numOfIndex;
    for(i=0;i<22;i+=2){
      indices[i+p]=index;
      indices[p+i+1]=index+1;
      index++;
      numOfIndex+=2;
    }
    //num-22 so 11
    numOfIndex+=2;
    indices[numOfIndex-2]=index;
    indices[numOfIndex-1]=numOfVertsC/3-12;
    
    if(numOfCyl>0){
      var index=(numOfVertsC/3)-24;
      for (var i = 0; i < 24; i+=2) {
        indices[numOfIndex+i]=index;
        indices[numOfIndex+i+1]=12+index;
        index++;
      }
      numOfIndex+=24;
    }
    //should be 12ish?
    //------------------------------------------

    pVec=new Vector3([0,0,.05]);
    //the indicies connect to themselves/ completes the circle
    cVert[numOfVertsC]=backPoint.x;
    cVert[numOfVertsC+1]=backPoint.y;
    cVert[numOfVertsC+2]=.05;
    //creats the perpendicular variable off by .1 in the z verticy
    numOfVertsC+=3;

    var num=0;
    var amountOfV=numOfVertsC;
    for (var i = 0; i <= 10; i++) {
      pVec=rotMatrix.multiplyVector3(pVec);
      num=amountOfV+i*3;
      cVert[num]=backPoint.x+pVec.elements[0];
      cVert[num+1]=backPoint.y+pVec.elements[1];
      cVert[num+2]=pVec.elements[2];
      numOfVertsC+=3;
    }
    index=numOfVertsC/3 - 12;
    //12
    //starts at 0 and gets 1 for every index added
    var p=numOfIndex;
    for(i=0;i<22;i+=2){
      indices[i+p]=index;
      indices[p+i+1]=index+1;
      index++;
      numOfIndex+=2;
    }
    numOfIndex+=2;
    indices[numOfIndex-2]=index;
    indices[numOfIndex-1]=numOfVertsC/3-12;
    console.log(numOfVertsC);

    var p=numOfIndex;

    var index=(numOfVertsC/3)-24;
    for (var i = 0; i < 24; i+=2) {
      indices[numOfIndex+i]=index;
      indices[numOfIndex+i+1]=12+index;
      index++;
    }
    numOfIndex+=24;
    //also make a connection to the prev circle
    //if its not the first cylinder and connect from  -72 in the cVert array will be the place of connection to -108

    numOfCyl++;
    //make another circle on the other side
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, cVert, gl.STATIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW);
    gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    gl.drawElements(gl.LINES,numOfIndex,gl.UNSIGNED_SHORT,0);

  }
  
}
function click(ev, gl, canvas, a_Position) {
  //changes background color everytime you click
  gl.clearColor(Math.floor(Math.random()*100)/100,
         Math.floor(Math.random()*100)/100,
         Math.floor(Math.random()*100)/100,
         Math.floor(Math.random()*100)/100);
  if(enableMove){
    //code from the examples given that gets the mouse position
    var x = ev.clientX;
    var y = ev.clientY; 
    var rect = ev.target.getBoundingClientRect() ;
    //0 is left
    //2 is right
    x = ((x - rect.left) - canvas.width/2)/(canvas.width/2);
    y = (canvas.height/2 - (y - rect.top))/(canvas.height/2);
    //check to see if its divisible by 2 to draw the cylinde
    //to start draw at every point
    if(ev.button==0){
      var z=0;
      numOfVerts+=3;
      //indices[indices.length]=numOfVerts/2;
      lineVert[numOfVerts-3]=x;
      lineVert[numOfVerts-2]=y;
      lineVert[numOfVerts-1]=z
      //if its divisible by 2 drawCircle from the last 6 xyz in lineVert
      if(numOfVerts>3){
         drawCircle(gl);
         console.log("VertNumberLine: "+numOfVerts);
         console.log("VertNumberShape: "+numOfVertsC);
         console.log("IndexNumber: "+numOfIndex);
         //show indicies
         for (var i = 0; i < numOfIndex; i++) {
           console.log("I"+i+": "+indices[i] );
         }
      }

      //make it a point perpendicular
      //console.log(x+", "+y+", "+z);
    }else if(ev.button==2){
      enableMove=false;
    }
    //gl.clear(gl.COLOR_BUFFER_BIT);

  }

}
//reads the data from the saved SOR file and fills the arrays for drawing
function readSOR(){
  console.log(indices[numOfIndex]);
  var SORObj = readFile();
  console.log(SORObj);
  //reset all the variables and arrays then load them in like this
  if(SORObj!=null){
    
    var numV=0;
    for(i=0;i<5000;i++){
      cVert[i]=SORObj.vertices[i];
      numV++;
    }

    var num=0;
    for(i=0;i<SORObj.indexes[4999];i++){
      indices[i]=SORObj.indexes[i];
      num++;
    }
    

    console.log("4999: "+num);
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, cVert, gl.STATIC_DRAW);

    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW);

    gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    gl.drawElements(gl.LINES,num,gl.UNSIGNED_SHORT,0);
    
  }
}
//saves the cylinder as an obj
function saveSOR(){
  indices[4999]=numOfIndex;
  //stores indexNumber at highest possible point lol
  //dont woray
  var p = prompt("Please enter your file name", "temperooni");

  if (p != null) {
    document.getElementById("fileName").innerHTML =p;
  }

  saveFile(new SOR(p, cVert, indices));
}